<?php
class Shortcounterhistory extends CI_Model {
 
 function getShortcounterhistory(){
  $this->db->select("mold_setting,model,shot_current,shot_setting,hard_current,hard_setting,change_current,change_setting,status_running,m_c"); 
  $this->db->from('status_mold');
  $query = $this->db->get();
  return $query->result();
 }
 
}
?>
<!-- 
CREATE TABLE status_mold(id int PRIMARY KEY not null IDENTITY(1,1), mold_setting varchar(150) not null,model varchar(150) not null, shot_current varchar(150) not null,shot_setting varchar(150) not null,hard_current varchar(150) not null,hard_setting varchar(150) not null,change_current varchar(150) not null,change_setting varchar(150) not null,status_running varchar(150) not null,m_c varchar(150) not null) -->


<!-- 
CREATE TABLE status_warning_display(id int PRIMARY KEY not null IDENTITY(1,1), mold_setting varchar(150) not null,model varchar(150) not null, shot_current varchar(150) not null,shot_setting varchar(150) not null,hard_current varchar(150) not null,hard_setting varchar(150) not null,change_current varchar(150) not null,change_setting varchar(150) not null,status_running varchar(150) not null,m_c varchar(150) not null) -->

<!-- INSERT status_mold(mold_setting, model, shot_current, shot_setting,hard_current,hard_setting,change_current,change_setting,status_running,m_c) VALUES ('HP-8', 'KV488', 3300, 6000,11245,30000,121113,10000,1,'HOTPRESS 8') -->

<!-- CREATE TABLE history_display(id int PRIMARY KEY not null IDENTITY(1,1), date date not null,short_history_count varchar(150) not null, shot_counter_status varchar(150) not null,hard_history_count varchar(150) not null, hard_counter_status varchar(150) not null,change_boxes_history_count varchar(150) not null, change_boxes_status varchar(150) not null,cleaner_shot VARCHAR(20) not NULL,cleaner_setting VARCHAR(20)not NULL,cleaner_status VARCHAR(20) not NULL,change_box_shot VARCHAR(20) not NULL,hard_chrom_shot VARCHAR(20) not NULL,hard_chrom_setting VARCHAR(20) not NULL,hard_chrom_status VARCHAR(20) not NULL)
 -->

 <!-- ALTER TABLE history_display ADD  cleaner_setting VARCHAR(20)not NULL,cleaner_status VARCHAR(20) not NULL,hard_short VARCHAR(20) not NULL,change_box_shot VARCHAR(20) not NULL; -->