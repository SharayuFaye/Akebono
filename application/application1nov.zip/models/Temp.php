<?php
class Temp extends CI_Model {
 
 function getTemp(){
  $this->db->select("hotpress_time,upper_upper_temp,upper_lower_temp,middle_upper_temp,middle_lower_temp,lower_upper_temp,lower_lower_temp,pressure"); 
  $this->db->from('temp_press');
  $query = $this->db->get();
  return $query->result();
 }
 
}
?>

<!-- 
CREATE TABLE status_mold(id int PRIMARY KEY not null IDENTITY(1,1), mold_setting varchar(150) not null,model varchar(150) not null, shot_current varchar(150) not null,shot_setting varchar(150) not null,hard_current varchar(150) not null,hard_setting varchar(150) not null,change_current varchar(150) not null,change_setting varchar(150) not null,status_running varchar(150) not null,m_c varchar(150) not null) -->


<!-- 
CREATE TABLE status_warning_display
(id int PRIMARY KEY not null IDENTITY(1,1), mold_setting varchar(150) not null,model varchar(150) not null, shot_current varchar(150) not null,shot_setting varchar(150) not null,hard_current varchar(150) not null,hard_setting varchar(150) not null,change_current varchar(150) not null,change_setting varchar(150) not null,status_running varchar(150) not null,m_c varchar(150) not null,deatils varchar(150)) -->

<!-- INSERT status_mold(mold_setting, model, shot_current, shot_setting,hard_current,hard_setting,change_current,change_setting,status_running,m_c) VALUES ('HP-8', 'KV488', 3300, 6000,11245,30000,121113,10000,1,'HOTPRESS 8') -->

<!-- ALTER TABLE history_display ADD cleaner_shot VARCHAR(20) not NULL, cleaner_setting VARCHAR(20)not NULL,cleaner_status VARCHAR(20) not NULL,hard_short VARCHAR(20) not NULL,change_box_shot VARCHAR(20) not NULL; -->

<!-- CREATE TABLE login(id int PRIMARY KEY not null IDENTITY(1,1), username varchar(150) not null,password varchar(150) not null) -->

<!-- INSERT login(username, password) VALUES ('admin', '123') -->

<!-- CREATE TABLE production(id int PRIMARY KEY not null IDENTITY(1,1), date date not null,time time not null, item VARCHAR(20) not NULL,hot_press VARCHAR(20) not NULL,mold_no VARCHAR(20) not NULL, udl VARCHAR(20) not NULL, pcs VARCHAR(20) not NULL, upper_temp VARCHAR(20) not NULL, lower_temp VARCHAR(20) not NULL)
 -->

<!-- INSERT production(date,time,item,hot_press,mold_no,udl,pcs,upper_temp,lower_temp) VALUES('18-Aug-18', '15:50:00','PU305','5','HP-1','Up die','6','161.5','160.0') -->


<!-- CREATE TABLE forecast(id int PRIMARY KEY not null IDENTITY(1,1), mold_item VARCHAR(150),forecast VARCHAR(150), no_value VARCHAR(150),jan VARCHAR(150),feb VARCHAR(150),mar VARCHAR(150),apr VARCHAR(150),may VARCHAR(150),jun VARCHAR(150),jul VARCHAR(150),aug VARCHAR(150),sep VARCHAR(150),oct VARCHAR(150),nov VARCHAR(150),dec VARCHAR(150),sum VARCHAR(150),cost VARCHAR(150),cost1 VARCHAR(150)) -->

<!-- INSERT forecast(mold_item,forecast,no_value,jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec,sum,cost,cost1) VALUES('EFC', '2018','forecast','23,450','23569','25698','60000','16152','16020','23569','25698','60000','16152','16020','16020',' ',' ',' '),(' ',' ','actual','23,450','23569','25698','60000','16152','16020','23569','25698','0','0','0','0',' ',' ',' ') -->

<!-- CREATE TABLE temp_press(id int PRIMARY KEY not null IDENTITY(1,1), hotpress_time date,item VARCHAR(150), upper_upper_temp VARCHAR(150),upper_lower_temp VARCHAR(150),middle_upper_temp VARCHAR(150),middle_lower_temp VARCHAR(150),lower_upper_temp VARCHAR(150),upper_lower_temp VARCHAR(150),jun VARCHAR(150),jul VARCHAR(150),aug VARCHAR(150),sep VARCHAR(150),oct VARCHAR(150),nov VARCHAR(150),dec VARCHAR(150),sum VARCHAR(150),cost VARCHAR(150),cost1 VARCHAR(150)) -->

<!-- CREATE TABLE temp_press(id int PRIMARY KEY not null IDENTITY(1,1), hotpress_time date,item VARCHAR(150), upper_upper_temp VARCHAR(150),upper_lower_temp VARCHAR(150),middle_upper_temp VARCHAR(150),middle_lower_temp VARCHAR(150),lower_upper_temp VARCHAR(150),upper_lower_temp VARCHAR(150),jun VARCHAR(150),jul VARCHAR(150),aug VARCHAR(150),sep VARCHAR(150),oct VARCHAR(150),nov VARCHAR(150),dec VARCHAR(150),sum VARCHAR(150),cost VARCHAR(150),cost1 VARCHAR(150)) -->

<!-- CREATE TABLE temp_press(id int PRIMARY KEY not null IDENTITY(1,1), hotpress_time date,item VARCHAR(150), upper_upper_temp VARCHAR(150),upper_lower_temp VARCHAR(150),middle_upper_temp VARCHAR(150),middle_lower_temp VARCHAR(150),lower_upper_temp VARCHAR(150),upper_lower_temp VARCHAR(150),jun VARCHAR(150),jul VARCHAR(150),aug VARCHAR(150),sep VARCHAR(150),oct VARCHAR(150),nov VARCHAR(150),dec VARCHAR(150),sum VARCHAR(150),cost VARCHAR(150),cost1 VARCHAR(150)) -->


<!-- CREATE TABLE temp_press(id int PRIMARY KEY not null IDENTITY(1,1), hotpress_time datetime,item VARCHAR(150), upper_upper_temp VARCHAR(150),upper_lower_temp VARCHAR(150),middle_upper_temp VARCHAR(150),middle_lower_temp VARCHAR(150),lower_upper_temp VARCHAR(150),lower_lower_temp VARCHAR(150),pressure VARCHAR(150)) -->

<!-- INSERT temp_press(hotpress_time, item, upper_upper_temp, upper_lower_temp,middle_upper_temp,middle_lower_temp,lower_upper_temp,lower_lower_temp,pressure) VALUES ('0001-01-01 ', 'KV488', 'KV488', 'KV488','KV488','KV488','KV488',KV488','HOTPRESS 8') -->

<!-- INSERT temp_press(hotpress_time, item, upper_upper_temp, upper_lower_temp,middle_upper_temp,middle_lower_temp,lower_upper_temp,lower_lower_temp,pressure) VALUES ('1900-01-01 00:00:00', 'KV488','KV488','KV488','KV488','KV488','KV488','KV488','KV488') -->