<?php
class production extends CI_Model {
 
 function getproduction(){
  $this->db->select("date,time,item,hot_press,mold_no,udl,pcs,upper_temp,lower_temp"); 
  $this->db->from('production');
  $query = $this->db->get();
  return $query->result();
 }
 
}
?>

<!-- CREATE TABLE production(id int PRIMARY KEY not null IDENTITY(1,1), date date not null,time time not null, item VARCHAR(20) not NULL,hot_press VARCHAR(20) not NULL,mold_no VARCHAR(20) not NULL, udl VARCHAR(20) not NULL, pcs VARCHAR(20) not NULL, upper_temp VARCHAR(20) not NULL, lower_temp VARCHAR(20) not NULL)
 -->