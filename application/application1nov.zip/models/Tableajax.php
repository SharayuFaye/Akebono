<?php
class Tableajax extends CI_Model {
 
 function getTableajax(){
  $this->db->select("mold,model,details,date"); 
  $this->db->from('status_warning_display');
  $query = $this->db->get();
  return $query->result();
 }
 
}
?>

<!-- 
CREATE TABLE status_mold(id int PRIMARY KEY not null IDENTITY(1,1), mold_setting varchar(150) not null,model varchar(150) not null, shot_current varchar(150) not null,shot_setting varchar(150) not null,hard_current varchar(150) not null,hard_setting varchar(150) not null,change_current varchar(150) not null,change_setting varchar(150) not null,status_running varchar(150) not null,m_c varchar(150) not null) -->


<!-- 
CREATE TABLE status_warning_display
(id int PRIMARY KEY not null IDENTITY(1,1), mold_setting varchar(150) not null,model varchar(150) not null, shot_current varchar(150) not null,shot_setting varchar(150) not null,hard_current varchar(150) not null,hard_setting varchar(150) not null,change_current varchar(150) not null,change_setting varchar(150) not null,status_running varchar(150) not null,m_c varchar(150) not null) -->

<!-- INSERT status_mold(mold_setting, model, shot_current, shot_setting,hard_current,hard_setting,change_current,change_setting,status_running,m_c) VALUES ('HP-8', 'KV488', 3300, 6000,11245,30000,121113,10000,1,'HOTPRESS 8') -->