<?php
class Mold extends CI_Model {
 
 function getMold(){
  $this->db->select("req_num,quatation_no,rfq_no,pr,no,part_no,description,quantity,unit,unit_cost,discount,amount,required_by,objective,mp_no,due_date,no_po,tax_invoice,receive_date,new_hard_chrome,data_inspection"); 
  $this->db->from('mold');
  $query = $this->db->get();
  return $query->result();
 }
 
}
?>



<!-- CREATE TABLE mold(id int PRIMARY KEY not null IDENTITY(1,1),req_num VARCHAR(20) not NULL,quatation_no VARCHAR(20) not NULL,rfq_no VARCHAR(20) not NULL, pr VARCHAR(20) not NULL, no VARCHAR(20) not NULL,part_no VARCHAR(20) not NULL, description VARCHAR(20) , quantity VARCHAR(20),unit VARCHAR(20) not NULL,unit_cost VARCHAR(20) not NULL,discount VARCHAR(20) not NULL,amount VARCHAR(20) ,required_by VARCHAR(20) not NULL,objective VARCHAR(20) not NULL, mp_no VARCHAR(20) not NULL, due_date date not NULL ,no_po date not NULL,tax_invoice  VARCHAR(20) not NULL,receive_date  date not NULL,new_hard_chrome  VARCHAR(20) not NULL,data_inspection  VARCHAR(20) not NULL)
 -->



<!-- INSERT mold(req_num, quatation_no, rfq_no, pr,no,part_no,description,quantity,unit,unit_cost,discount,amount,required_by,objective,mp_no,due_date,no_po,tax_invoice,receive_date,new_hard_chrome,data_inspection) VALUES ('M1800166', 'A1801-444',  111, '02/08/2018',1,230075000011,'HARD CHORM PUNCH NO.BD03-003 Model :610',4,'pc',1500,111,6000,'Khanchai K.','Hard Chrome Mold Hot-Press Model:AN-610','MT09','23/02/2018','AK180608','277128794','20/3/2018','Hard Chrome',111 ) -->

<!-- alter table mold add mold_item varchar(50) -->