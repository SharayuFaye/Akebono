<?php
class Moldsetting extends CI_Model {
 
 function getMoldsetting(){
  $this->db->select("model,mold,cavity,m_c,clean_set,hard_chrom_set,die_change_set,qua_att,req_chorm,die_change,price_hard_chrom,price_die_change"); 
  $this->db->from('mold_setting');
  $query = $this->db->get();
  return $query->result();
 }

 function saverecords($model,$mold,$cavity,$clean_set,$hard_chrom_set,$m_c,$die_change_set,$qua_att,$req_chorm,$die_change,$price_hard_chrom,$price_die_change)
	{
		alert('ok');
	$query="insert into mold_setting values('$model','$mold','cavity','$m_c','$clean_set','$hard_chrom_set','$die_change_set','$qua_att','$req_chorm','$die_change','$price_hard_chrom','$price_die_change')";
	$this->db->query($query);
	print_r($query);

	}
 
}

