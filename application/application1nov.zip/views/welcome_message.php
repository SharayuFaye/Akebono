<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


<style>
.dot {
    height:15px;
    width: 15px;
    background-color: green;
    border-radius: 50%;
    display: inline-block;
}
.dot1 {
    height:15px;
    width: 15px;
    background-color: black;
    border-radius: 50%;
    display: inline-block;
}
.button {
    background-color:#04d59b; /* Green */
    border: none;
    color: white;
    padding: 6px 7px 16px 9px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 2px 78px 9px 39px;
    cursor: pointer;
    
}
.button_wel {
    background-color: #04d59b;
    border: none;
    color: white;
    /* padding: 6px 7px 16px 9px; */
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 14px;
    margin: 2px 78px 9px 39px;
    cursor: pointer;
    width: 288px;
    height: 55px;
}
</style>
			<div class="inner-wrapper">
				
				<section role="main" class="content-body">
					<header class="page-header" style="background-color: #e60018;">
						<!-- <h2>Responsive Tables</h2> -->
					
						<div class="right-wrapper text-right">
							<ol class="breadcrumbs">
								<li>		
								</li>
							</ol>
					
							
						</div>
					</header>


						<div class="row">
							<div class="col" >
								<section class="card">
									<header class="card-header">
										<div class="card-actions">
											<a href="#" class="card-action card-action-toggle" data-card-toggle></a>
											<a href="#" class="card-action card-action-dismiss" data-card-dismiss></a>
										</div>
						
										<h2 class="card-title" style="color:black;">Status Mold Display</h2>
										<div style="text-align: right;margin: -26px 75px 26px -4px;color: #008000;">Green:Running</div>
										<div style="text-align: right;margin: -30px 54px 7px 2px;color: black">Black:Not Running</div>
									</header>

									<div class="card-body">
	<table class="table table-responsive-lg table-bordered table-striped table-sm mb-0">
		<thead>
			<tr>
				<th colspan="8" style="text-align: center;background-color: #026AB7;
color: white;">Mold ID Status Display</th>
				<th rowspan="3" style="text-align: center;background-color: #026AB7;
color: white;">Status Running</th>
				<th rowspan="3" style="text-align: center;background-color: #026AB7;
color: white;">M/C</th>
			</tr>
             <tr> 
				<th rowspan="2" style="text-align: center;background-color: #026AB7;
color: white;">Mold/setting</th>
				<th rowspan="2" style="text-align: center;background-color: #026AB7;
color: white;">Model</th>
				<th colspan="2" style="text-align: center;background-color: #026AB7;
color: white;">Short Counter</th>
				<th colspan="2" style="text-align: center;background-color: #026AB7;
color: white;">Hard Chrome</th>
				<th colspan="2" style="text-align: center;background-color: #026AB7;
color: white;">Die Change </th>
			</tr>
			<tr> 
				<th style="text-align: center;background-color: #026AB7;
color: white;" >Current</th>
				<th style="text-align: center;background-color: #026AB7;
color: white;" >Setting</th>
				<th style="text-align: center;background-color: #026AB7;
color: white;">Current</th>
				<th style="text-align: center;background-color: #026AB7;
color: white;">Setting</th>
				<th style="text-align: center;background-color: #026AB7;
color: white;">Current</th>
				<th style="text-align: center;background-color: #026AB7;
color: white;">Setting</th>
			</tr>
													
											</thead>
											<tbody><!-- <button id="subm1">Open Modal</button> -->
                       <?php foreach($posts as $post){?>
						<tr data-toggle="modal" class="open-my-modal" data-target="#myModal" data-id="<?php echo $post->mold_setting;?>" data-model-id="<?php echo $post->model;?>" data-shot_current="<?php echo $post->shot_current;?>" 
							data-change_current="<?php echo $post->change_current;?>"
							data-hard_current="<?php echo $post->hard_current;?>">
								<td ><?php echo $post->mold_setting;?></td>
								<td><?php echo $post->model;?></a></td>
								<td><?php echo $post->shot_current;?></td>
								<td ><?php echo $post->shot_setting;?></td>
								<td ><?php echo $post->hard_current;?></td>
								<td ><?php echo $post->hard_setting;?></td>
								<td ><?php echo $post->
								change_current;?></td>
								<td ><?php echo $post->change_setting;?></td>
								<td ><?php if ($post->status_running == 1){	echo'<span class="dot"></span>';
								  }else{echo'
									<span class="dot1"></span>';
									}?></td>
								<td ><?php echo $post->m_c;?></span></td> 
								<?php }?> 
						</a>	</tr>												
											</tbody>
										</table>

<script type="text/javascript">
	$(document).ready(function () {             
    $('.open-my-modal').click(function(){
        $('#order-id').html($(this).data('id'));
        $('#model-id').html($(this).data('model-id'));
        $('#shot_current').html($(this).data('shot_current'));
        $('#hard_current').html($(this).data('hard_current')); 
        $('#shot_id').val($(this).data('shot_current')); 
        $('#hard_id').val($(this).data('hard_current'));
        $('#model_id').val($(this).data('model-id'));
         $('#myModal').modal('show');
    });
});
</script>

	<div class="modal fade" id="myModal" role="dialog" data-target="#exampleModal">
    <div class="modal-dialog">
       <div class="modal-content" style="width: 155%;">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" style="margin: 0px 0px 0px 0px !important; padding: 0px 0px 0px 0px !important;">&times;</button>
          <h4 class="modal-title" style="margin-right: 263px;">Mold identification system</h4>
        </div>
<div class="modal-body">
 	<table class="table table-responsive-lg table-bordered table-striped table-sm mb-0">
	<thead> <tr> <p> Current Mold Data</p>		 	</thead>
	<tbody>
	<tr> <td>Mold id:</td> 	<td> <div  id='mold-id'></div> </td> </tr>	
	<tr> <td>Model Name:</td> <td> <div  id='model-id'></div> </td> </tr>	
	<tr> <td>Current shots:</td> <td><div  id='shot_current'></div></td></tr>
	<tr><td>Maximum shots:</td><td><div  id='Maximum'></div></td></tr>	
	<tr><td>Hard chrome shots:</td><td><div id='hard_current'></div></td></tr>	
	<tr><td>Last Wash date:</td><td><?php echo date('Y/m/d');?><div  id='prod-id'></div></td></tr>	
	<tr><td>Last Hard chrome date:</td><td><?php echo date('Y/m/d');?><div  id='prod-id'></div></td>
	</tr>	
	<tr><td>Last block change date :</td><td><?php echo date('Y/m/d');?><div  id='prod-id'></div></td>
	</tr>												
			</tbody>
		</table>
        </div>
        <?php $this->load->helper('form');?>
   <?php echo form_open('Welcome/welcome_message'); ?>      
         <div class="row">
    	<input type="hidden" name="model" id="model_id" >
    	<input type="hidden" name="shot_current" id="shot_id" >
    	<input type="hidden" name="hard_chrome" id="hard_id" >

    <div class="col-sm-6"><input type="submit" name="Currentshots" class="btn btn-primary button_wel" value="Clean Switch &#187; Click "   ></div>
    <div class="col-sm-6"><input type="submit" class="btn btn-primary button_wel" name="Hardchromeshots" value="Hard Chrome &#187; Click "></div>
  </div>
   <div class="row">
    <div class="col-sm-6"><input type="submit" class="btn btn-primary button_wel" name="Diechange" value="Die Change Switch &#187; Click"></div>

    <?php echo form_close(); ?>
    <div class="col-sm-6"><input type="submit" class="btn btn-primary button_wel"  value="History of Mold &#187; Click"></div>
  </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div></div>
								<div style="margin: 5px 0px 0px -23px;">
								<span class="dot"></span><div style="margin: -23px 0px 0px 51px;">Mold running in machine</div>
										<span class="dot1"></span><div style="margin: -23px 0px 0px 51px;">Mold standby</div>
										</div>
									</div>
								</section>
								</div>
						</div>				
				</section>
			</div>		
		</section>

		
		