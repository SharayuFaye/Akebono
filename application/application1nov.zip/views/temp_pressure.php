<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript">
	
	$(function() {
    var header_height = 0;
    $('table tr .ht th .vertical-text').each(function() {
        if ($(this).outerWidth() > header_height) header_height = $(this).outerWidth();
    });

    $('table tr .ht  th ').height(header_height);
});
</script>

<style>
  tr .ht th{
	color:black;
}
table, tr, td, th { 
  position: relative; 
   
} 

th  .vertical-text {
  transform-origin: 0 50%;
  transform: rotate(-90deg); 
  white-space: nowrap; 
  display: block;
  position: absolute;
  bottom: 0;
  left: 50%;
}
.vertical-text {
	 transform-origin: 0 50%;
  transform: rotate(-90deg); 
  white-space: nowrap; 
  display: block;
  position: absolute;
  bottom: 0;
  left: 50%;
}


.dot {
    height:15px;
    width: 15px;
    background-color: green;
    border-radius: 50%;
    display: inline-block;
}
.dot1 {
    height:15px;
    width: 15px;
    background-color: black;
    border-radius: 50%;
    display: inline-block;
}
.button {
    background-color:#2F68AE; /* Green */
    border: none;
    color: white;
    padding:7px 18px 9px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 2px 78px 9px 0px;
    cursor: pointer;
    
}
</style>
			<div class="inner-wrapper">
				
				<section role="main" class="content-body">
					<header class="page-header" style="background-color: #e60018;">
						<div class="right-wrapper text-right">
							<ol class="breadcrumbs">
								<li>		
								</li>
							</ol>					
						</div>
					</header>
						<div class="row">
							<div class="col" >
								<section class="card">
									<header class="card-header">
										<div class="card-actions">
											<a href="#" class="card-action card-action-toggle" data-card-toggle></a>
											<a href="#" class="card-action card-action-dismiss" data-card-dismiss></a>
										</div>
						
										<h2 class="card-title" style="color: black;">Temperature & Pressure</h2>
									<!-- 	<div style="text-align: right;margin: -26px 75px 26px -4px;color: #008000;">Green:Running</div>
										<div style="text-align: right;margin: -30px 54px 7px 2px;color: black">Black:Not Running</div> -->
									</header>

									<div class="card-body">
 
										<table class="table table-responsive-lg table-bordered table-striped table-sm mb-0">
											<thead>
												<tr>
										<th colspan="15" style="background-color: #026AB7;
    color: white;">Hotpress:1</th>
										
												</tr>
                          <tr class="ht"> 
 <th     style="text-align: center;background-color: #026AB7;
    color: white;"> </th>
    <th     style="text-align: center;background-color: #026AB7;
    color: white;"> </th>
    <th colspan="2" style="text-align: center;background-color: #026AB7;
    color: white;">Upper</th>
    
     <th colspan="2" style="text-align: center;background-color: #026AB7;
    color: white;">Middle</th>
     <th colspan="2" style="text-align: center;background-color: #026AB7;
    color: white;">Lower</th>
    <th  style="text-align: center;background-color: #026AB7;
    color: white;"> </th>
												</tr>
 <tr style="    height: 160px;"> 

<th  rowspan="2"  style="text-align: center;background-color: #026AB7;
    color: white;">Time</th>
    <th  rowspan="2"  style="text-align: center;background-color: #026AB7;
    color: white;"><span class="vertical-text">Item</span></th>

    <th  style="text-align: center;background-color: #026AB7;
    color: white;"><span class="vertical-text">Upper Upper temp &#x2103;</span></th>
	 <th style="text-align: center;background-color: #026AB7;
    color: white;"><span class="vertical-text">Upper Lower temp &#x2103;</span></th>
    <th style="text-align: center;background-color: #026AB7;
    color: white;"><span class="vertical-text">Middle Upper temp &#x2103;</span></th>
     <th style="text-align: center;background-color: #026AB7;
    color: white;"><span class="vertical-text">Middle Lower temp &#x2103;</span></th>
    <th style="text-align: center;background-color: #026AB7;
    color: white;"><span class="vertical-text">Lower Upper temp &#x2103;</span></th>
     <th style="text-align: center;background-color: #026AB7;
    color: white;"><span class="vertical-text">Lower Lower temp &#x2103;</span></th> 
    <th style="text-align: center;background-color: #026AB7; color: white;">Pressure</th>


												</tr>
													
											</thead>
											<tbody><!-- <button id="subm1">Open Modal</button> -->
   <?php foreach($Temps as $Temp){?> 
		<tr>
				 <td ><?php echo $Temp->hotpress_time;?></td>
				<td><?php echo $Temp->upper_upper_temp;?></a></td>
				<td><?php echo $Temp->upper_lower_temp;?></td>
					<td><?php echo $Temp->middle_upper_temp;?></td>
				<td ><?php echo $Temp->middle_lower_temp;?></td>
				<td ><?php echo $Temp->lower_upper_temp;?></td>
				<td ><?php echo $Temp->lower_lower_temp;?></td>
				<td ><?php echo $Temp->pressure;?></td>
				<td > </td>
									<?php }?>  
		</a>	</tr>												
											</tbody>
										</table>
<!-- <button onclick="myFunction()" class="button button2">Add</button> -->
<script>
function myFunction() {
    var x = document.getElementById("myDIV");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
</script>
<div id="myDIV" style="display: none;background: #f6f6f6;">
                      <?php $this->load->helper('form');?>
   <?php echo form_open('Welcome/Moldsetting'); ?> 
                     <tr>
 

<div class="container-fluid">
  <div class="row">
    <div class="col-sm-4" > Model:<br>
  <input type="text" name="model" value=""></div>
    <div class="col-sm-4"> Mold:<br>
  <input type="text" name="mold" value=""></div><!-- 
   
   <button class="button button2" name="save" type="submit" style="margin: 2px 78px 9px 14px;">Save</button>
  </div>
</div> 
                                        </tr>
                                       <!--  <button class="button button2" name="save" type="submit" >Save</button> -->
               <!--  </table> -->
                <?php echo form_close(); ?>

            </div>
	<div class="modal fade" id="myModal" role="dialog" data-target="#exampleModal">
    <div class="modal-dialog">
       <div class="modal-content" style="width: 155%;">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" style="margin: 0px 0px 0px 0px !important; padding: 0px 0px 0px 0px !important;">&times;</button>
          <h4 class="modal-title" style="margin-right: 263px;">Mold identification system</h4>
        </div>
        <div class="modal-body">
         	<table class="table table-responsive-lg table-bordered table-striped table-sm mb-0">
											<thead>
												<tr>
													<p> Current Mold Data</p>		
											</thead>
											<tbody>
											<tr>
													<td>Mold Name:</td>
													<td>
														<div  id='prod-id'></div>
													</td>
										</tr>	
											<tr>
													<td>Mold id:</td>
													
													<td><!-- <?php foreach($posts as $post){?><?php echo $post->mold_setting;?><?php }?> -->
														<div  id='sell-id'></div>
													</td>
										</tr>	
											<tr>
													<td>Current shots:</td>
													<td><div  id='shot_current-id'></div></td>
										</tr>	
											<tr>
													<td>Maximum shots:</td>
													
													<td><!-- <?php foreach($posts as $post){?><?php echo $post->model;?><?php }?> --><div  id='shot_setting-id'></div></td>
										</tr>	


											<tr>
													<td>Hard chrome shots:</td>
													<td><?php foreach($posts as $post){?><?php echo $post->model;?><?php }?><div  id='prod-id'></div></td>
										</tr>	
											<tr>
													<td>Last Wash date:</td>
													
													<td><?php foreach($posts as $post){?><?php echo $post->model;?><?php }?><div  id='prod-id'></div></td>
										</tr>	
											<tr>
													<td>Last Hard chrome date:</td>
													<td><?php foreach($posts as $post){?><?php echo $post->model;?><?php }?><div  id='prod-id'></div></td>
										</tr>	
											<tr>
													<td>Last block change date :</td>
													
													<td><?php foreach($posts as $post){?><?php echo $post->model;?><?php }?><div  id='prod-id'></div></td>
										</tr>												
											</tbody>
										</table>
        </div>
         <div class="row">
    <div class="col-sm-6"><button class="button">Reset mold current short >> click</button></div>
    <div class="col-sm-6"><button class="button">Reset mold hard chrome short >>click</button></div>
  </div>
   <div class="row">
    <div class="col-sm-6"><button class="button">Inset custom mold physical specific >>click</button></div>
    <div class="col-sm-6"><button class="button">show this mold historical >>click</button></div>
  </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div></div>
									</div>
								</section>
								</div>
						</div>				
				</section>
			</div>		
		</section>

		
		