<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 
<script type="text/javascript" src="../js/jquery.js"></script>
<style>
.dot {
    height:15px;
    width: 15px;
    background-color: blue;
    border-radius: 50%;
    display: inline-block;
}
.dot1 {
    height:15px;
    width: 15px;
    background-color: black;
    border-radius: 50%;
    display: inline-block;
}
.button {
    background-color:#026AB7; /* Green */
    border: none;
    color: white;
    padding: 6px 7px 16px 9px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 2px 78px 9px 39px;
    cursor: pointer;
    
}
</style>
 <script type="text/javascript"> 
 $(document).ready(function(){ 
  var s1 = [2, 6, 7, 10];
  var s2 = [7, 5, 3, 4];
  var s3 = [14, 9, 3, 8];
  plot3 = $.jqplot('chart3', [s1, s2, s3], {
    // Tell the plot to stack the bars.
    stackSeries: true,
    captureRightClick: true,
    seriesDefaults:{
      renderer:$.jqplot.BarRenderer,
      rendererOptions: {
          // Put a 30 pixel margin between bars.
          barMargin: 30,
          // Highlight bars when mouse button pressed.
          // Disables default highlighting on mouse over.
          highlightMouseDown: true   
      },
      pointLabels: {show: true}
    },
    axes: {
      xaxis: {
          renderer: $.jqplot.CategoryAxisRenderer
      },
      yaxis: {
        // Don't pad out the bottom of the data range.  By default,
        // axes scaled as if data extended 10% above and below the
        // actual range to prevent data points right on grid boundaries.
        // Don't want to do that here.
        padMin: 0
      }
    },
    legend: {
      show: true,
      location: 'e',
      placement: 'outside'
    }      
  });
  // Bind a listener to the "jqplotDataClick" event.  Here, simply change
  // the text of the info3 element to show what series and ponit were
  // clicked along with the data for that point.
  $('#chart3').bind('jqplotDataClick', 
    function (ev, seriesIndex, pointIndex, data) {
      $('#info3').html('series: '+seriesIndex+', point: '+pointIndex+', data: '+data);
    }
  ); 
});

</script> 
<html class="fixed">
	<head>

		<!-- Basic -->
		<meta charset="UTF-8">

		<title>Charts | Porto Admin - Responsive HTML5 Template 2.0.0</title>
		<meta name="keywords" content="HTML5 Admin Template" />
		<meta name="description" content="Porto Admin - Responsive HTML5 Template">
		<meta name="author" content="okler.net">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- Web Fonts  -->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.css" />
		<link rel="stylesheet" href="../vendor/animate/animate.css">

		<link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.css" />
		<link rel="stylesheet" href="../vendor/magnific-popup/magnific-popup.css" />
		<link rel="stylesheet" href="../vendor/bootstrap-datepicker/css/bootstrap-datepicker3.css" />

		<!-- Specific Page Vendor CSS -->
		<link rel="stylesheet" href="../vendor/morris/morris.css" />
		<link rel="stylesheet" href="../vendor/chartist/chartist.min.css" />

		<!-- Theme CSS -->
		<link rel="stylesheet" href="../css/theme.css" />

		<!-- Skin CSS -->
		<link rel="stylesheet" href="../css/skins/default.css" />

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="../css/custom.css">

		<!-- Head Libs -->
		<script src="../vendor/modernizr/modernizr.js"></script>

  

<script type="text/javascript" src="../src/jquery.jqplot.js"></script>
<script type="text/javascript" src="../src/plugins/jqplot.barRenderer.js"></script>
<script type="text/javascript" src="../src/plugins/jqplot.categoryAxisRenderer.js"></script>
<script type="text/javascript" src="../src/plugins/jqplot.pointLabels.js"></script>
<link rel="stylesheet" type="text/css" href="../src/jquery.jqplot.css" />




	</head>
	<body>
		<section class="body">
	<header class="header">
				<div class="logo-container">
					<a href="<?php echo base_url();?>" class="logo">
						<img src="<?php echo base_url(); ?>img/logoA.png" width="200" height="45" alt="Porto Admin" />
					</a>
					<div class="d-md-none toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
						<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
					</div>
				</div>
			
				<!-- start: search & user box -->
				<div class="header-right">
			
					
						<div class="header-nav collapse">
						<div class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1">
						 <nav>
								<ul class="nav nav-pills" id="mainNav" style=" margin: 0px 266px 3px 2px;">
										<li class="dropdown">
									    <a class="nav-link dropdown-toggle" href="#">
									       Report Display
									    </a>
									    <ul class="dropdown-menu">
									        <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/welcome_message">
									               Status Mold Display
									            </a>
									        </li>
									        <li>

									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/tableajax">

                                                   Report Status Warning Display
									                
									            </a>
									        </li>
									        <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Statushistory">
									                Status History Display
									            </a>
									        </li>
									       <!--  <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Statushistory1">
									                Status History Display1
									            </a>
									        </li> -->
									      <!--   <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Shortcounterhistory">
									                Report History Shot Counter
									            </a>
									        </li> -->
									    </ul>
									</li>
									<li class=" dropdown">
									    <a class="nav-link dropdown-toggle" href="<?php echo base_url(); ?>index.php/Moldsetting">
									        Report Mold Setting
									    </a>
									     <ul class="dropdown-menu">
									        <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Moldsetting">
									               Report Mold Setting
									            </a>
									        </li>
									       <!--  <li>

									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Moldsetting1">

                               Report Mold Setting1     
									            </a>
									        </li> -->
									         <li>

									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/forecastsetting">

                               Forecast Setting  
									            </a>
									        </li>
									       <li>

									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Mold">

                               Mold  
									            </a>
									        </li> 
									        <!--  <li>

									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/production">

                               Production data logger 
									            </a>
									        </li> -->
									       
									    </ul>									    
									</li>
								<li class=" dropdown">
									   <a class="nav-link dropdown-toggle" href="#">
	                       Machine Control Mold  
									    </a>
									     <ul class="dropdown-menu">
									     	<li>
									            <a class="nav-link  " href="<?php echo base_url(); ?>index.php/Machinecontrol">
									               Machine Control Mold 
									            </a>
									        </li>
									        <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/production">
									               Production Data Logger
									            </a>
									        </li>
									      
									         <li>

									      <a class="nav-link" href="<?php echo base_url(); ?>index.php/Cleanhistory">
                                                    Cleaning History
									            </a>
									        </li> 

									         <li>

									        <a class="nav-link" href="<?php echo base_url(); ?>index.php/Machinerunning">
                                                   Machine Running Chart
									            </a>
									        </li> 
									    </ul>
								</li>
							</ul>
							</nav>
						</div>
					</div>
				
					<div id="userbox" class="userbox">
						<a href="#" data-toggle="dropdown">
							<figure class="profile-picture">
								<img src="<?php echo base_url(); ?>img/!logged-user.jpg" alt="Joseph Doe" class="rounded-circle" data-lock-picture="img/!logged-user.jpg" />
							</figure>
							<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@okler.com">
								<span class="name">
									<?php echo $this->session->userdata['logged_in']['username']; ?>
								</span>
								<span class="role">Administrator</span>
							</div>
			
							<i class="fa custom-caret"></i>
						</a>
			
					</div>
				</div>
				<!-- end: search & user box -->
			</header>
			<div class="inner-wrapper">
				

				<section role="main" class="content-body">
					<header class="page-header">
						<!-- <h2>Charts</h2> -->
					
						<div class="right-wrapper text-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>UI Elements</span></li>
								<li><span>Charts</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
							<div class="col-lg-6">
								<section class="card"   style="margin-right: -443px;"  >
									<header class="card-header">
										<div class="card-actions">
											<a href="#" class="card-action card-action-toggle" data-card-toggle></a>
											<a href="#" class="card-action card-action-dismiss" data-card-dismiss></a>
										</div>
						
										<h2 class="card-title">Cleaning History</h2>
									<!-- 	<p class="card-subtitle">With the categories plugin you can plot categories/textual data easily.</p> -->

<!-- <?php $this->load->helper('form');?>
   <?php echo form_open('Welcome/cleanhistory'); ?>  -->											
  <div class="row"> 
       <div class="col-sm-4" style="    margin: 27px 16px -12px -16px;"> Search:<br>
       	<input type="date" name="startdate"  placeholder="Start date">
       	<input type="date" name="enddate"  placeholder="End date"></div>
       	 <div class="col-sm-8" style="    margin: 23px 16px -12px -16px;"> Action:<br>
       	 	 
       	 	<select>
       	 		<option>Clean</option>
       	 		<option>Hard Chrom</option>
       	 		<option>Die Change</option>
       	 	</select>

 <input class="btn btn-primary  button button2" name="submit" type="submit" value="Submit"/> 

 <!-- <?php echo form_close(); ?>  -->
 </header> 
									<div class="card-body"> 
										<!-- Flot: Bars -->
										<div class="chart chart-md" id="flotBars"></div>


 <script type='text/javascript'  language='javascript'> 
	$(document).ready(function(){
		// post_array =
		// {
		//     "myvar" : "value1",
		//     "myvar2": "value2"
		// } 

// 		$.get("<?php echo base_url();?>index.php/cleanhistorydata", post_array,
// 		    function(data)
// 		    {
// 		        var res =  data ;
		        
// 		        var flotBarsData =	 [
// 						["Jan", 10],
// 						["Feb", 10],
// 						["Mar", 10],
// 						["Apr", 10],
// 						["May", 10],
// 						["Jun", 10],
// 						["Jul", 10],
// 						["Aug", 10],
// 						["Sep", 10],
// 						["Oct", 10],
// 						["Sep", 10],
// 						["Oct", 10],
// 						["Nov", 10],
// 						["Dec", 10]
// 			 	]; 
// 			 	alert(flotBarsData);
// 		    });

// alert(flotBarsData);
	    // $.ajax({
     //        url:"<?php echo base_url();?>index.php/cleanhistorydata",
     //        type: 'GET',
     //        dataType: 'JSON', 
     //        success:function (data) {
     //        	alert(11111);
     //        	 var flotBarsData =	 [
					// 	["Jan", 10],
					// 	["Feb", 10],
					// 	["Mar", 10],
					// 	["Apr", 10],
					// 	["May", 10],
					// 	["Jun", 10],
					// 	["Jul", 10],
					// 	["Aug", 10],
					// 	["Sep", 10],
					// 	["Oct", 10],
					// 	["Sep", 10],
					// 	["Oct", 10],
					// 	["Nov", 10],
					// 	["Dec", 10]
			 	// ]; 
     //        } ,
     //    error: function(){
     //        alert('Could not load the data');
     //    }
     //    });
     //    event.preventDefault();
 
 });
// 
var flotBarsData = [
						["Jan", 10],
						["Feb", 10],
						["Mar", 10],
						["Apr", 10],
						["May", 10],
						["Jun", 10],
						["Jul", 10],
						["Aug", 10],
						["Sep", 10],
						["Oct", 10],
						["Sep", 10],
						["Oct", 10],
						["Nov", 10],
						["Dec", 10]
			 	];
						 
											// See: js/examples/examples.charts.js for more settings.
						
										</script>
						
									</div>
								</section>
							</div>
							<div class="col-lg-6">
								<section class="card" style="margin-right: -469px;">
									<!-- <header class="card-header"> -->
										<div class="card-actions">
											<a href="#" class="card-action card-action-toggle" data-card-toggle></a>
											<a href="#" class="card-action card-action-dismiss" data-card-dismiss></a>
										</div>
						
										<!-- <h2 class="card-title">Pie Chart</h2>
										<p class="card-subtitle">Default Pie Chart</p> -->
									</header>
									
								</section>
							</div>
						</div>
						
					<!-- end: page -->
				</section>
			</div>
		</section>
 <!--  <?php
 
$dataPoints1 = array( 
	array("label" => "",  "y" => 50 ),
	array("label" => "", "y" => 28 )
	
);
 
$dataPoints2 = array( 
	array("label" => "",  "y" => 25 ),
	array("label" => "", "y" => 30 )
	
);
 
$dataPoints3 = array( 
	array("label" => "",  "y" => 13 ),
	array("label" => "", "y" => 25 )
	
);
 
$dataPoints4 = array( 
	array("label" => "",  "y" => 12 ),
	array("label" => "", "y" => 17 )

);
 
?>
<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		//text: "Social Media Engagement"
	},
	toolTip: {
		shared: true
	},
	axisY: {
		//title: "Percentage of Users",
		suffix: "%"
	},
	data: [{
		type: "stackedBar100",
		name: "More than Once a day",
		yValueFormatString: "#,##0\"%\"",
		dataPoints: <?php echo json_encode($dataPoints1, JSON_NUMERIC_CHECK); ?>
	},{
		type: "stackedBar100",
		yValueFormatString: "#,##0\"%\"",
		name: "Daily",
		dataPoints: <?php echo json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
	},{
		type: "stackedBar100",
		yValueFormatString: "#,##0\"%\"",
		name: "Weekly",
		dataPoints: <?php echo json_encode($dataPoints3, JSON_NUMERIC_CHECK); ?>
	},{
		type: "stackedBar100",
		yValueFormatString: "#,##0\"%\"",
		name: "Less Often",
		dataPoints: <?php echo json_encode($dataPoints4, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script> -->

<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>  

		<!-- Vendor -->
		<script src="../vendor/jquery/jquery.js"></script>
		<script src="../vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="../vendor/popper/umd/popper.min.js"></script>
		<script src="../vendor/bootstrap/js/bootstrap.js"></script>
		<script src="../vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
		<script src="../vendor/common/common.js"></script>
		<script src="../vendor/nanoscroller/nanoscroller.js"></script>
		<script src="../vendor/magnific-popup/jquery.magnific-popup.js"></script>
		<script src="../vendor/jquery-placeholder/jquery-placeholder.js"></script>
		
		<!-- Specific Page Vendor -->
		<script src="../vendor/jquery-appear/jquery-appear.js"></script>
		<script src="../vendor/jquery.easy-pie-chart/jquery.easy-pie-chart.js"></script>
		<script src="../vendor/flot/jquery.flot.js"></script>
		<script src="../vendor/flot.tooltip/flot.tooltip.js"></script>
		<script src="../vendor/flot/jquery.flot.pie.js"></script>
		<script src="../vendor/flot/jquery.flot.categories.js"></script>
		<script src="../vendor/flot/jquery.flot.resize.js"></script>
		<script src="../vendor/jquery-sparkline/jquery-sparkline.js"></script>
		<script src="../vendor/raphael/raphael.js"></script>
		<script src="../vendor/morris/morris.js"></script>
		<script src="../vendor/gauge/gauge.js"></script>
		<script src="../vendor/snap.svg/snap.svg.js"></script>
		<script src="../vendor/liquid-meter/liquid.meter.js"></script>
		<script src="../vendor/chartist/chartist.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="../js/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="../js/custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="../js/theme.init.js"></script>

		<!-- Examples -->
		<style>
			#ChartistCSSAnimation .ct-series.ct-series-a .ct-line {
				fill: none;
				stroke-width: 4px;
				stroke-dasharray: 5px;
				-webkit-animation: dashoffset 1s linear infinite;
				-moz-animation: dashoffset 1s linear infinite;
				animation: dashoffset 1s linear infinite;
			}

			#ChartistCSSAnimation .ct-series.ct-series-b .ct-point {
				-webkit-animation: bouncing-stroke 0.5s ease infinite;
				-moz-animation: bouncing-stroke 0.5s ease infinite;
				animation: bouncing-stroke 0.5s ease infinite;
			}

			#ChartistCSSAnimation .ct-series.ct-series-b .ct-line {
				fill: none;
				stroke-width: 3px;
			}

			#ChartistCSSAnimation .ct-series.ct-series-c .ct-point {
				-webkit-animation: exploding-stroke 1s ease-out infinite;
				-moz-animation: exploding-stroke 1s ease-out infinite;
				animation: exploding-stroke 1s ease-out infinite;
			}

			#ChartistCSSAnimation .ct-series.ct-series-c .ct-line {
				fill: none;
				stroke-width: 2px;
				stroke-dasharray: 40px 3px;
			}

			@-webkit-keyframes dashoffset {
				0% {
					stroke-dashoffset: 0px;
				}

				100% {
					stroke-dashoffset: -20px;
				};
			}

			@-moz-keyframes dashoffset {
				0% {
					stroke-dashoffset: 0px;
				}

				100% {
					stroke-dashoffset: -20px;
				};
			}

			@keyframes dashoffset {
				0% {
					stroke-dashoffset: 0px;
				}

				100% {
					stroke-dashoffset: -20px;
				};
			}

			@-webkit-keyframes bouncing-stroke {
				0% {
					stroke-width: 5px;
				}

				50% {
					stroke-width: 10px;
				}

				100% {
					stroke-width: 5px;
				};
			}

			@-moz-keyframes bouncing-stroke {
				0% {
					stroke-width: 5px;
				}

				50% {
					stroke-width: 10px;
				}

				100% {
					stroke-width: 5px;
				};
			}

			@keyframes bouncing-stroke {
				0% {
					stroke-width: 5px;
				}

				50% {
					stroke-width: 10px;
				}

				100% {
					stroke-width: 5px;
				};
			}

			@-webkit-keyframes exploding-stroke {
				0% {
					stroke-width: 2px;
					opacity: 1;
				}

				100% {
					stroke-width: 20px;
					opacity: 0;
				};
			}

			@-moz-keyframes exploding-stroke {
				0% {
					stroke-width: 2px;
					opacity: 1;
				}

				100% {
					stroke-width: 20px;
					opacity: 0;
				};
			}

			@keyframes exploding-stroke {
				0% {
					stroke-width: 2px;
					opacity: 1;
				}

				100% {
					stroke-width: 20px;
					opacity: 0;
				};
			}
		</style>
		<script src="../js/examples/examples.charts.js"></script>

	</body>
</html>