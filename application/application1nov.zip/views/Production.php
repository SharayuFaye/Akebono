<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


<style>
.dot {
    height:15px;
    width: 15px;
    background-color: green;
    border-radius: 50%;
    display: inline-block;
}
.dot1 {
    height:15px;
    width: 15px;
    background-color: black;
    border-radius: 50%;
    display: inline-block;
}
.button {
    background-color:#04d59b; /* Green */
    border: none;
    color: white;
    padding: 6px 7px 16px 9px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 2px 78px 9px 39px;
    cursor: pointer;
    
}
</style>
			<div class="inner-wrapper">
				
				<section role="main" class="content-body">
					<header class="page-header" style="background-color: #e60018;">
						<!-- <h2>Responsive Tables</h2> -->
					
						<div class="right-wrapper text-right">
							<ol class="breadcrumbs">
								<li>		
								</li>
							</ol>
					
							
						</div>
					</header>


						<div class="row">
							<div class="col" >
								<section class="card">
									<header class="card-header">
										<div class="card-actions">
											<a href="#" class="card-action card-action-toggle" data-card-toggle></a>
											<a href="#" class="card-action card-action-dismiss" data-card-dismiss></a>
										</div>
						
										<h2 class="card-title" style="color: black;">Production Data Logger</h2>
										<!-- <div style="text-align: right;margin: -26px 75px 26px -4px;color: #008000;">Green:Running</div>
										<div style="text-align: right;margin: -30px 54px 7px 2px;color: black">Black:Not Running</div> -->
									</header>

									<div class="card-body">
										<table class="table table-responsive-lg table-bordered table-striped table-sm mb-0">
											<thead>
												<tr>
													<th  style="text-align: center;background-color: #026AB7;
    color: white;">Date</th>
													<th style="text-align: center;background-color: #026AB7;
    color: white;">Time</th>
													<th style="text-align: center;background-color: #026AB7;
    color: white;">Item</th>


    <th  style="text-align: center;background-color: #026AB7;
    color: white;">Hot press M/C</th>
													<th style="text-align: center;background-color: #026AB7;
    color: white;">Mold No.</th>
													<th style="text-align: center;background-color: #026AB7;
    color: white;">Up/Down/Lower</th>

    <th  style="text-align: center;background-color: #026AB7;
    color: white;">Pcs.</th>
													<th style="text-align: center;background-color: #026AB7;
    color: white;">Upper temp  &#x2103;</th>
													<th style="text-align: center;background-color: #026AB7;
    color: white;">Lower temp  &#x2103;</th>
												</tr>
                                                	
											</thead>
											<tbody><!-- <button id="subm1">Open Modal</button> -->
                       <?php foreach($Productions as $Production){?> 
											<tr>
											<td><!-- <?php echo $Production->date;?> --> 
                                            <?php  
                                            echo date('d-M-Y', strtotime($Production->date));
                                            ?> </td>
                                            <td><?php  
                                            echo date('h:i A', strtotime($Production->time));
                                            ?> </td>
                                            <td><?php echo $Production->item;?> </td>
                                            <td><?php echo $Production->hot_press;?></td>
                                            <td><?php echo $Production->mold_no;?> </td>
                                            <td><?php echo $Production->udl;?> </td>
										<td ><?php echo $Production->pcs;?></span></td> 
                                        <td ><?php echo $Production->upper_temp;?></span></td> 
                                        <td ><?php echo $Production->lower_temp;?></span></td> 

											<?php }?>  
											</a>	</tr>												
											</tbody>
										</table>
                                        

<script>
function myFunction() {
    var x = document.getElementById("myDIV");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
</script>

	<div class="modal fade" id="myModal" role="dialog" data-target="#exampleModal">
    <div class="modal-dialog">
       <div class="modal-content" style="width: 155%;">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" style="margin: 0px 0px 0px 0px !important; padding: 0px 0px 0px 0px !important;">&times;</button>
          <h4 class="modal-title" style="margin-right: 263px;">Mold identification system</h4>
        </div>
        <div class="modal-body">
         
        </div>
         <div class="row">
    <div class="col-sm-6"><button class="button">Reset mold current short >> click</button></div>
    <div class="col-sm-6"><button class="button">Reset mold hard chrome short >>click</button></div>
  </div>
   <div class="row">
    <div class="col-sm-6"><button class="button">Inset custom mold physical specific >>click</button></div>
    <div class="col-sm-6"><button class="button">show this mold historical >>click</button></div>
  </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div></div>
								<!-- <div style="margin: 5px 0px 0px -23px;">
								<span class="dot"></span><div style="margin: -23px 0px 0px 51px;">Mold running in machine</div>
										<span class="dot1"></span><div style="margin: -23px 0px 0px 51px;">Mold standby</div>
										</div> -->
									</div>
								</section>
								</div>
						</div>				
				</section>
			</div>		
		</section>

		
		