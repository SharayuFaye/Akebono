<script type="text/javascript">$(document).ready(function(){
  var s1 = [2, 6, 7, 10];
  var s2 = [7, 5, 3, 4];
  var s3 = [14, 9, 3, 8];
  plot3 = $.jqplot('chart3', [s1, s2, s3], {
    // Tell the plot to stack the bars.
    stackSeries: true,
    captureRightClick: true,
    seriesDefaults:{
      renderer:$.jqplot.BarRenderer,
      rendererOptions: {
          // Put a 30 pixel margin between bars.
          barMargin: 30,
          // Highlight bars when mouse button pressed.
          // Disables default highlighting on mouse over.
          highlightMouseDown: true   
      },
      pointLabels: {show: true}
    },
    axes: {
      xaxis: {
          renderer: $.jqplot.CategoryAxisRenderer
      },
      yaxis: {
        // Don't pad out the bottom of the data range.  By default,
        // axes scaled as if data extended 10% above and below the
        // actual range to prevent data points right on grid boundaries.
        // Don't want to do that here.
        padMin: 0
      }
    },
    legend: {
      show: true,
      location: 'e',
      placement: 'outside'
    }      
  });
  // Bind a listener to the "jqplotDataClick" event.  Here, simply change
  // the text of the info3 element to show what series and ponit were
  // clicked along with the data for that point.
  $('#chart3').bind('jqplotDataClick', 
    function (ev, seriesIndex, pointIndex, data) {
      $('#info3').html('series: '+seriesIndex+', point: '+pointIndex+', data: '+data);
    }
  ); 
});</script>
<html class="fixed">
	<head>

		<!-- Basic -->
		<meta charset="UTF-8">

		<title>Charts | Porto Admin - Responsive HTML5 Template 2.0.0</title>
		<meta name="keywords" content="HTML5 Admin Template" />
		<meta name="description" content="Porto Admin - Responsive HTML5 Template">
		<meta name="author" content="okler.net">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- Web Fonts  -->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.css" />
		<link rel="stylesheet" href="../vendor/animate/animate.css">

		<link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.css" />
		<link rel="stylesheet" href="../vendor/magnific-popup/magnific-popup.css" />
		<link rel="stylesheet" href="../vendor/bootstrap-datepicker/css/bootstrap-datepicker3.css" />

		<!-- Specific Page Vendor CSS -->
		<link rel="stylesheet" href="../vendor/morris/morris.css" />
		<link rel="stylesheet" href="../vendor/chartist/chartist.min.css" />

		<!-- Theme CSS -->
		<link rel="stylesheet" href="../css/theme.css" />

		<!-- Skin CSS -->
		<link rel="stylesheet" href="../css/skins/default.css" />

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="../css/custom.css">

		<!-- Head Libs -->
		<script src="../vendor/modernizr/modernizr.js"></script>



<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="../src/jquery.jqplot.js"></script>
<script type="text/javascript" src="../src/plugins/jqplot.barRenderer.js"></script>
<script type="text/javascript" src="../src/plugins/jqplot.categoryAxisRenderer.js"></script>
<script type="text/javascript" src="../src/plugins/jqplot.pointLabels.js"></script>
<link rel="stylesheet" type="text/css" href="../src/jquery.jqplot.css" />
	</head>
	<!-- <body> -->
		<!-- <section class="body"> -->
	<header class="header">
				<div class="logo-container">
					<a href="<?php echo base_url();?>" class="logo">
						<img src="<?php echo base_url(); ?>img/logoA.png" width="200" height="45" alt="Porto Admin" />
					</a>
					<div class="d-md-none toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
						<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
					</div>
				</div>
			
				<!-- start: search & user box -->
				<div class="header-right">
			
					
						<div class="header-nav collapse">
						<div class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1">
						 <nav>
								<ul class="nav nav-pills" id="mainNav" style=" margin: 0px 266px 3px 2px;">
										<li class="dropdown">
									    <a class="nav-link dropdown-toggle" href="#">
									       Report Display
									    </a>
									    <ul class="dropdown-menu">
									        <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/welcome_message">
									               Status Mold Display
									            </a>
									        </li>
									        <li>

									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/tableajax">

                                                   Report Status Warning Display
									                
									            </a>
									        </li>
									        <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Statushistory">
									                Status History Display
									            </a>
									        </li>
									       <!--  <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Statushistory1">
									                Status History Display1
									            </a>
									        </li> -->
									      <!--   <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Shortcounterhistory">
									                Report History Shot Counter
									            </a>
									        </li> -->
									    </ul>
									</li>
									<li class=" dropdown">
									    <a class="nav-link dropdown-toggle" href="<?php echo base_url(); ?>index.php/Moldsetting">
									        Report Mold Setting
									    </a>
									     <ul class="dropdown-menu">
									        <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Moldsetting">
									               Report Mold Setting
									            </a>
									        </li>
									       <!--  <li>

									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Moldsetting1">

                               Report Mold Setting1     
									            </a>
									        </li> -->
									         <li>

									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/forecastsetting">

                               Forecast Setting  
									            </a>
									        </li>
									        <li>

									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Mold">

                               Mold  
									            </a>
									        </li> 
									        <!--  <li>

									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/production">

                               Production data logger 
									            </a>
									        </li> -->
									       
									    </ul>									    
									</li>
								<li class=" dropdown">
									   <a class="nav-link dropdown-toggle" href="#">
	                       Machine Control Mold  
									    </a>
									     <ul class="dropdown-menu">
									     	<li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/Machinecontrol">
									               Machine Control Mold 
									            </a>
									        </li>
									        <li>
									            <a class="nav-link" href="<?php echo base_url(); ?>index.php/production">
									               Production Data Logger
									            </a>
									        </li>
									      
									         <li>

									      <a class="nav-link" href="<?php echo base_url(); ?>index.php/Cleanhistory">
                                                    Cleaning History
									            </a>
									        </li> 

									         <li>

									        <a class="nav-link" href="<?php echo base_url(); ?>index.php/Machinerunning">
                                                   Machine Running Chart
									            </a>
									        </li> 
									    </ul>
								</li>
							</ul>
							</nav>
						</div>
					</div>
					<div id="userbox" class="userbox">
						<a href="#" data-toggle="dropdown">
							<figure class="profile-picture">
								<img src="<?php echo base_url(); ?>img/!logged-user.jpg" alt="Joseph Doe" class="rounded-circle" data-lock-picture="img/!logged-user.jpg" />
							</figure>
							<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@okler.com">
								<span class="name">
									<?php echo $this->session->userdata['logged_in']['username']; ?>
								</span>
								<span class="role">Administrator</span>
							</div>
			
							<i class="fa custom-caret"></i>
						</a>
			
					</div>
				
				</div>
				<!-- end: search & user box -->
			</header>
			
		</section>
		<header class="page-header">
						<!-- <h2>Charts</h2> -->
					
						<div class="right-wrapper text-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>UI Elements</span></li>
								<li><span>Charts</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>

						<h2 style="color:black" class="card-title">Machine Running Chart</h2>
					</header>

<?php
 
$dataPoints1 = array( 
	array("label" => "1403",  "y" => 10 ),
	array("label" => "1505", "y" => 10 ) 
);
 
$dataPoints2 = array( 
	array("label" => "1403",  "y" => 12 ),
	array("label" => "1505", "y" => 17 ) 
);
  
 
?>
<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		//text: "Social Media Engagement"
	},
	toolTip: {
		shared: true
	},
	axisY: {
		//title: "Percentage of Users",
		suffix: "%"
	},
	data: [{
		type: "stackedBar100",
		name: "More than Once a day",
		yValueFormatString: "#,##0\"%\"",
		dataPoints: <?php echo json_encode($dataPoints1, JSON_NUMERIC_CHECK); ?>
	},{
		type: "stackedBar100",
		yValueFormatString: "#,##0\"%\"",
		name: "Daily",
		dataPoints: <?php echo json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
	},
	{
		type: "stackedBar100",
		name: "More than Once a day",
		yValueFormatString: "#,##0\"%\"",
		dataPoints: <?php echo json_encode($dataPoints1, JSON_NUMERIC_CHECK); ?>
	},{
		type: "stackedBar100",
		yValueFormatString: "#,##0\"%\"",
		name: "Daily",
		dataPoints: <?php echo json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
	},
	{
		type: "stackedBar100",
		name: "More than Once a day",
		yValueFormatString: "#,##0\"%\"",
		dataPoints: <?php echo json_encode($dataPoints1, JSON_NUMERIC_CHECK); ?>
	},{
		type: "stackedBar100",
		yValueFormatString: "#,##0\"%\"",
		name: "Daily",
		dataPoints: <?php echo json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
	} ]
});
chart.render();
 
}
</script>
</head>
<body>

<div id="chartContainer" style="height: 370px; width: 100%; 
    margin:152px 0px 0px 2px;">

</div>
<script src="../js/canvasjs.min.js"></script>
</body>
</html>     

      

		<!-- Vendor -->
		<script src="../vendor/jquery/jquery.js"></script>
		<script src="../vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="../vendor/popper/umd/popper.min.js"></script>
		<script src="../vendor/bootstrap/js/bootstrap.js"></script>
		<script src="../vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
		<script src="../vendor/common/common.js"></script>
		<script src="../vendor/nanoscroller/nanoscroller.js"></script>
		<script src="../vendor/magnific-popup/jquery.magnific-popup.js"></script>
		<script src="../vendor/jquery-placeholder/jquery-placeholder.js"></script>
		
		<!-- Specific Page Vendor -->
		<script src="../vendor/jquery-appear/jquery-appear.js"></script>
		<script src="../vendor/jquery.easy-pie-chart/jquery.easy-pie-chart.js"></script>
		<script src="../vendor/flot/jquery.flot.js"></script>
		<script src="../vendor/flot.tooltip/flot.tooltip.js"></script>
		<script src="../vendor/flot/jquery.flot.pie.js"></script>
		<script src="../vendor/flot/jquery.flot.categories.js"></script>
		<script src="../vendor/flot/jquery.flot.resize.js"></script>
		<script src="../vendor/jquery-sparkline/jquery-sparkline.js"></script>
		<script src="../vendor/raphael/raphael.js"></script>
		<script src="../vendor/morris/morris.js"></script>
		<script src="../vendor/gauge/gauge.js"></script>
		<script src="../vendor/snap.svg/snap.svg.js"></script>
		<script src="../vendor/liquid-meter/liquid.meter.js"></script>
		<script src="../vendor/chartist/chartist.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="../js/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="../js/custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="../js/theme.init.js"></script>

		<!-- Examples -->
		<style>
			#ChartistCSSAnimation .ct-series.ct-series-a .ct-line {
				fill: none;
				stroke-width: 4px;
				stroke-dasharray: 5px;
				-webkit-animation: dashoffset 1s linear infinite;
				-moz-animation: dashoffset 1s linear infinite;
				animation: dashoffset 1s linear infinite;
			}

			#ChartistCSSAnimation .ct-series.ct-series-b .ct-point {
				-webkit-animation: bouncing-stroke 0.5s ease infinite;
				-moz-animation: bouncing-stroke 0.5s ease infinite;
				animation: bouncing-stroke 0.5s ease infinite;
			}

			#ChartistCSSAnimation .ct-series.ct-series-b .ct-line {
				fill: none;
				stroke-width: 3px;
			}

			#ChartistCSSAnimation .ct-series.ct-series-c .ct-point {
				-webkit-animation: exploding-stroke 1s ease-out infinite;
				-moz-animation: exploding-stroke 1s ease-out infinite;
				animation: exploding-stroke 1s ease-out infinite;
			}

			#ChartistCSSAnimation .ct-series.ct-series-c .ct-line {
				fill: none;
				stroke-width: 2px;
				stroke-dasharray: 40px 3px;
			}

			@-webkit-keyframes dashoffset {
				0% {
					stroke-dashoffset: 0px;
				}

				100% {
					stroke-dashoffset: -20px;
				};
			}

			@-moz-keyframes dashoffset {
				0% {
					stroke-dashoffset: 0px;
				}

				100% {
					stroke-dashoffset: -20px;
				};
			}

			@keyframes dashoffset {
				0% {
					stroke-dashoffset: 0px;
				}

				100% {
					stroke-dashoffset: -20px;
				};
			}

			@-webkit-keyframes bouncing-stroke {
				0% {
					stroke-width: 5px;
				}

				50% {
					stroke-width: 10px;
				}

				100% {
					stroke-width: 5px;
				};
			}

			@-moz-keyframes bouncing-stroke {
				0% {
					stroke-width: 5px;
				}

				50% {
					stroke-width: 10px;
				}

				100% {
					stroke-width: 5px;
				};
			}

			@keyframes bouncing-stroke {
				0% {
					stroke-width: 5px;
				}

				50% {
					stroke-width: 10px;
				}

				100% {
					stroke-width: 5px;
				};
			}

			@-webkit-keyframes exploding-stroke {
				0% {
					stroke-width: 2px;
					opacity: 1;
				}

				100% {
					stroke-width: 20px;
					opacity: 0;
				};
			}

			@-moz-keyframes exploding-stroke {
				0% {
					stroke-width: 2px;
					opacity: 1;
				}

				100% {
					stroke-width: 20px;
					opacity: 0;
				};
			}

			@keyframes exploding-stroke {
				0% {
					stroke-width: 2px;
					opacity: 1;
				}

				100% {
					stroke-width: 20px;
					opacity: 0;
				};
			}
		</style>
		<script src="../js/examples/examples.charts.js"></script>
	</body>
</html>