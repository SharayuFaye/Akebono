

			<div class="inner-wrapper">
				<!-- start: sidebar -->
		
				<!-- end: sidebar -->
				<section role="main" class="content-body card-margin">
					<header class="page-header">
						<!-- <h2>Basic Tables</h2> -->
					
						<div class="right-wrapper text-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Tables</span></li>
								<li><span>Basic</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<div class="row">
							
						</div>
						
						<div class="row">
							
						</div>
						
						<div class="row">
							<div class="col-lg-12">
							<form id="form" action="forms-validation.html" class="form-horizontal">
								<section class="card">
									<header class="card-header">
										<div class="card-actions">
											<a href="#" class="card-action card-action-toggle" data-card-toggle></a>
											<a href="#" class="card-action card-action-dismiss" data-card-dismiss></a>
										</div>

										<h2 class="card-title">Report Mold Search</h2>
										
									</header>
									<div class="card-body">
										<div class="form-group row">
											<label class="col-sm-3 control-label text-sm-right pt-2">Active Time <span class="required"></span></label>
											<div class="col-sm-4">
												<input type="date" name="fullname" class="form-control" placeholder="" required/>
											</div>
											<div class="col-sm-4">
												<input type="date" name="fullname" class="form-control" placeholder="" required/>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-sm-3 control-label text-sm-right pt-2">Select <span class="required"></span></label>
											<div class="col-sm-9">
												<div class="input-group">
												
													<input type="url" name="github" class="form-control" placeholder="eg.: https://github.com/johndoe" />
												</div>
											</div>
											<div class="col-sm-9">

											</div>
										</div>
										<div class="form-group row">
											<label class="col-sm-3 control-label text-sm-right pt-2">Where</label>
											<div class="col-sm-9">
												<input type="url" name="github" class="form-control" placeholder="eg.: https://github.com/johndoe" />
											</div>
										</div>
									
									</div>
									<footer class="card-footer">
									
									</footer>
								</section>
							</form>
						</div>
							<div class="col-lg-12">
								<section class="card">
									<header class="card-header">
										<div class="card-actions">
											<a href="#" class="card-action card-action-toggle" data-card-toggle></a>
											<a href="#" class="card-action card-action-dismiss" data-card-dismiss></a>
										</div>
						
										<!-- <h2 class="card-title">Condensed</h2> -->
									</header>
									<div class="card-body">
										<table class="table table-responsive-md table-sm mb-0">
											<thead>
												<tr>
													<th>Mold</th>
													<th>Short Counter</th>
													<th>Work time(hr.)</th>
													<th>Mc</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>1</td>
													<td>Mark</td>
													<td>Otto</td>
													<td>@mdo</td>
												</tr>
												<tr>
													<td>2</td>
													<td>Jacob</td>
													<td>Thornton</td>
													<td>@fat</td>
												</tr>
												<tr>
													<td>3</td>
													<td>Larry</td>
													<td>the Bird</td>
													<td>@twitter</td>
												</tr>
												<tr>
													<td>4</td>
													<td>Mark</td>
													<td>Otto</td>
													<td>@mdo</td>
												</tr>
												<tr>
													<td>5</td>
													<td>Jacob</td>
													<td>Thornton</td>
													<td>@fat</td>
												</tr>
												<tr>
													<td>6</td>
													<td>Larry</td>
													<td>the Bird</td>
													<td>@twitter</td>
												</tr>
												<tr>
													<td>7</td>
													<td>Mark</td>
													<td>Otto</td>
													<td>@mdo</td>
												</tr>
												<tr>
													<td>8</td>
													<td>Jacob</td>
													<td>Thornton</td>
													<td>@fat</td>
												</tr>
												<tr>
													<td>9</td>
													<td>Jacob</td>
													<td>Thornton</td>
													<td>@fat</td>
												</tr>
												<tr>
													<td>10</td>
													<td>Larry</td>
													<td>the Bird</td>
													<td>@twitter</td>
												</tr>
											</tbody>
										</table>
									</div>
								</section>
							</div>
						</div>
						
						<div class="row">
							
						</div>
						
						<div class="row">
							
						</div>
					<!-- end: page -->
				</section>
			</div>
	</section>

	
