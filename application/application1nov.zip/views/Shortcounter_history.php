

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<aside id="sidebar-left" class="sidebar-left">
				
				    <div class="sidebar-header">
				        <div class="sidebar-title" style="color: #e60018">
				            Navigation
				        </div>
				        <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
				            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
				        </div>
				    </div>
				
				</aside>
				
				<!-- end: sidebar -->

				<section role="main" class="content-body">
					<header class="page-header">
						<!-- <h2>Ajax Tables</h2> -->
					
						<div class="right-wrapper text-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Tables</span></li>
								<li><span>Ajax</span></li>
							</ol>
						</div>
					</header>

					<!-- start: page -->
						<section class="card">
							<header class="card-header">
								<div class="card-actions">
									<a href="#" class="card-action card-action-toggle" data-card-toggle></a>
									<a href="#" class="card-action card-action-dismiss" data-card-dismiss></a>
								</div>
						
								<h2 class="card-title">Report Status Warning Display</h2>
							</header>
							<div class="card-body">
								<!-- <table class="table table-bordered table-striped" id="datatable-ajax" data-url="ajax/ajax-datatables-sample.json"> -->
									<table class="table table-responsive-lg table-bordered table-striped table-sm mb-0">
									<thead>
                                       <tr>
										<th colspan="4" style="text-align: center;background-color: #026AB7;
    color: white;">Mold ID status dispaly</th>
    </tr>
										<tr>
											<th width="20%">Mold</th>
											<th width="25%">Model</th>
											<th width="25%">details</th>
											<th width="15%">Date</th>
											<!-- <th width="15%">CSS grade</th> -->
										</tr>
									</thead>
									<tbody>
                                              
												<tr>
													<td></td>
													<td></td>
													<td></td>
													<td>27/09/2017</td>
													
												
												</tr>
												
												
											</tbody>
									<tbody>
									</tbody>
								</table>
							</div>
						</section>
					<!-- end: page -->
				</section>
			</div>

			
		</section>

		